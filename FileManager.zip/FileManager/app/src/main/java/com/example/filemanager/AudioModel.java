package com.example.filemanager;

public class AudioModel {
    String name;
    String data;

    public AudioModel(String name, String data) {
        this.name = name;
        this.data = data;
    }
}
