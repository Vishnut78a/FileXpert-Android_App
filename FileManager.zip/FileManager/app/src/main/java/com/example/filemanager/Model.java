package com.example.filemanager;

public class Model {
  int image;
  String name;

  public Model(int image, String name){
      this.image = image;
      this.name = name;
  }

}
