package com.example.filemanager;

public class PDFModel {
    String data;
    String name;
    public PDFModel(String data,String name){
        this.data = data;
        this.name =name;
    }

}
