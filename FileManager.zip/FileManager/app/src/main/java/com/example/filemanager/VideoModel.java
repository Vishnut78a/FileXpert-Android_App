package com.example.filemanager;

import android.graphics.Bitmap;

public class VideoModel {



}
