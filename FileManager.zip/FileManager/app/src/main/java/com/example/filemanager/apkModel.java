package com.example.filemanager;

import android.net.Uri;

public class apkModel {
    String name;
    Uri data;

    public apkModel(String name, Uri data) {
        this.name = name;
        this.data = data;
    }
}
