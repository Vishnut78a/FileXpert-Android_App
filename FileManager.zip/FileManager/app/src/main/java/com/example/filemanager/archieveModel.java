package com.example.filemanager;

import android.net.Uri;

public class archieveModel {
String name;
Uri uri;

    public archieveModel(String name, Uri uri) {
        this.name = name;
        this.uri = uri;
    }


}
